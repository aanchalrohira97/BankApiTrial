package com.example.bankapi.controller;

import java.util.*;
import java.util.ArrayList;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.bankapi.model.Bank_Customer;
import com.example.bankapi.service.Bank_Customer_Service;


//creating a REST api
@RestController
public class Bank_Controller {

	private Bank_Customer_Service BankCustService;
	

	@Autowired
	private SessionFactory sessionFactory;
	
	//get all the bank customers
	@GetMapping("/api/customers")
	public ResponseEntity<List<Bank_Customer>> list(){
		 List<Bank_Customer> customers = BankCustService.bank_customer_list();
		 //List<Bank_Customer> list = sessionFactory.getCurrentSession().createQuery("from bank_customer").list();
	      return ResponseEntity.ok().body(customers);
	}
	
}
